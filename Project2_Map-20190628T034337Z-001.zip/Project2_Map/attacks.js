var cities = [{
        name: "Paris",
        location: [48.8566, 2.3522]
    },
    {
        name: "Lyon",
        location: [45.7640, 4.8357]
    },
    {
        name: "Cannes",
        location: [43.5528, 7.0174]
    },
    {
        name: "Nantes",
        location: [47.2184, -1.5536]
    }
];